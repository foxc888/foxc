import os
from datetime import datetime

# 默认日志文件路径（可通过环境变量覆盖）
LOG_FILE = os.getenv("LOG_FILE", "/root/OpenClashManage/wangluo/log.txt")

# 是否在控制台也打印日志（可选）
ENABLE_CONSOLE = True

def write_log(message: str, module: str = ""):
    """写入日志，自动加时间戳和模块标识"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    tag = f"[{module.upper()}]" if module else ""
    line = f"{timestamp} {tag} {message}".strip()

    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as e:
        if ENABLE_CONSOLE:
            print(f"[log.py] ❌ 无法写入日志文件: {e}")

    if ENABLE_CONSOLE:
        print(line)

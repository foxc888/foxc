# log.py
from datetime import datetime
import os

# 确保日志文件夹存在
LOG_FILE = "/root/OpenClashManage/wangluo/log.txt"
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

def write_log(msg: str):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{now} {msg}"
    print(line)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as e:
        print(f"[log.py] Failed to write log: {e}")

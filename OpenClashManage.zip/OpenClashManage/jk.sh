#!/bin/bash

NODES_FILE="/root/OpenClashManage/wangluo/nodes.txt"
LOG_FILE="/root/OpenClashManage/wangluo/log.txt"
SCRIPT_TO_RUN="/root/OpenClashManage/zr.py"

echo "开始监控 $NODES_FILE 是否变化... $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"

LAST_HASH=""

while true
do
    if [ -f "$NODES_FILE" ]; then
        CURRENT_HASH=$(md5sum "$NODES_FILE" | awk '{print $1}')
        if [ "$CURRENT_HASH" != "$LAST_HASH" ]; then
            echo "✅ 检测到 nodes.txt 变动，执行同步... $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"

            if python3 "$SCRIPT_TO_RUN" >> "$LOG_FILE" 2>&1; then
                echo "✅ 同步执行完毕，已完成更新 $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
                LAST_HASH="$CURRENT_HASH"
            else
                echo "❌ 同步脚本执行失败，请检查 $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
            fi
        fi
    else
        echo "⚠️ $NODES_FILE 不存在，等待创建... $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
    fi

    sleep 5
done

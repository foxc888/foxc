#!/bin/bash

# === 设置路径 ===
NODES_FILE="/root/OpenClashManage/wangluo/nodes.txt"
CONFIG_FILE="/etc/openclash/config.yaml"
BACKUP_FILE="/etc/openclash/config.yaml.bak"
SCRIPT_TO_RUN="/root/OpenClashManage/zr.py"
LOG_FILE="/root/OpenClashManage/log.txt"
INTERVAL=5  # 轮询间隔秒数

# === 初始化哈希值 ===
LAST_HASH=""

echo "✅ OpenClash 节点同步守护启动中..." >> "$LOG_FILE"

while true; do
  # 检查文件是否存在
  if [ ! -f "$NODES_FILE" ]; then
    echo "⚠️ 文件不存在: $NODES_FILE" >> "$LOG_FILE"
    sleep $INTERVAL
    continue
  fi

  # 计算当前哈希
  CURRENT_HASH=$(md5sum "$NODES_FILE" | awk '{print $1}')

  # 比较哈希是否变化
  if [ "$CURRENT_HASH" != "$LAST_HASH" ]; then
    echo "🔄 检测到节点文件发生变动，准备执行同步 $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"

    # === 备份配置文件 ===
    cp "$CONFIG_FILE" "$BACKUP_FILE"

    # === 执行节点注入脚本 ===
    if python3 "$SCRIPT_TO_RUN" >> "$LOG_FILE" 2>&1; then
      echo "✅ 同步完成，OpenClash 配置文件已更新 $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
      LAST_HASH="$CURRENT_HASH"
    else
      echo "❌ 同步失败，恢复原始配置 $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
      cp "$BACKUP_FILE" "$CONFIG_FILE"
      /etc/init.d/openclash restart
    fi
  fi

  sleep $INTERVAL
done

# zc.py
import os
from datetime import datetime

def inject_groups(config, node_names: list) -> tuple:
    # 生成手机002 到 手机254
    target_groups = [f"手机{i}" for i in range(2, 255)]

    log_path = "/root/OpenClashManage/wangluo/log.txt"
    def write_log(msg):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] {msg}\n")

    proxy_groups = config.get("proxy-groups", [])
    group_map = {g["name"]: g for g in proxy_groups}
    injected_total = 0

    for group_name in target_groups:
        group = group_map.get(group_name)
        if not group:
            write_log(f"⚠️ 策略组 [{group_name}] 不存在，跳过注入")
            continue

        original = group.get("proxies", [])
        updated = []

        # 前缀保留顺序
        updated.append("REJECT")
        updated.append("DIRECT")

        added = 0
        for name in node_names:
            if name not in original:
                updated.append(name)
                added += 1
            else:
                updated.append(name)

        group["proxies"] = updated
        injected_total += added
        write_log(f"✅ 策略组 [{group_name}] 注入 {added} 个节点")

    config["proxy-groups"] = proxy_groups
    return config, injected_total

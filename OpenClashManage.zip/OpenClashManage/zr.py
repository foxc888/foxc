#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import yaml
import base64
import os
import json
import re
import socket
import time
import hashlib
from urllib.parse import unquote, urlparse, parse_qs
from datetime import datetime

lock_file = "/tmp/openclash_update.lock"
if os.path.exists(lock_file):
    print("⚠️ 已有运行中的更新任务，已退出避免重复执行。")
    exit(0)
open(lock_file, "w").close()

try:
    nodes_file = "/root/OpenClashManage/wangluo/nodes.txt"
    log_file_path = "/root/OpenClashManage/wangluo/log.txt"

    # === 精准补丁：仅在真实增删改节点时重启 ===
    def extract_clean_links(file_path):
        cleaned_links = []
        with open(file_path, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip() and not line.strip().startswith("#")]
            skip_next = False
            for idx, line in enumerate(lines):
                if skip_next:
                    skip_next = False
                    continue
                if idx + 1 < len(lines) and re.match(r'^[（(].*?[）)]$', lines[idx + 1]):
                    combined = line + lines[idx + 1]
                    cleaned_links.append(combined.strip().split("#")[0].strip())
                    skip_next = True
                else:
                    cleaned_links.append(line.strip().split("#")[0].strip())
        return cleaned_links

    real_links = extract_clean_links(nodes_file)
    current_md5 = hashlib.md5("\n".join(real_links).encode()).hexdigest()
    md5_record_file = "/root/OpenClashManage/wangluo/nodes_content.md5"

    previous_md5 = ""
    if os.path.exists(md5_record_file):
        with open(md5_record_file, "r") as f:
            previous_md5 = f.read().strip()

    config_file = os.popen("uci get openclash.config.config_path").read().strip()
    with open(config_file, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    existing_nodes_count = len(config.get("proxies") or [])

    if current_md5 == previous_md5:
        print(f"✅ nodes.txt 内容无变化，无需重启 OpenClash，当前节点数：{existing_nodes_count} 个")
        if os.path.exists(lock_file):
            os.remove(lock_file)
        exit(0)
    else:
        with open(md5_record_file, "w") as f:
            f.write(current_md5)

    # 执行前清空日志
    with open(log_file_path, "w", encoding="utf-8") as lf:
        lf.truncate(0)
    log_file = open(log_file_path, "a", encoding="utf-8")

    def ensure_unique_name(name):
        base = name
        idx = 1
        while name in used_names:
            name = f"{base}.{idx}"
            idx += 1
        used_names[name] = True
        return name

    def clean_name(name, max_length=24):
        name = re.sub(r'[\s\u3000]', '', name)
        name = re.sub(r'[\u200b\u200c\u200d\ufeff]', '', name)
        name = ''.join(ch for ch in name if ch.isprintable())
        return name[:max_length]

    def decode_base64(data: str) -> bytes:
        data += '=' * (-len(data) % 4)
        try:
            return base64.urlsafe_b64decode(data)
        except Exception as e:
            log_file.write(f"[Base64解码失败] {data} -> {e}\n")
            raise

    def strip_non_base64(s):
        s_clean = s.split('（')[0].split('(')[0].strip()
        return re.sub(r'[^A-Za-z0-9+/=]', '', s_clean)

    def parse_ss(raw_link, name):
        ss_url = unquote(raw_link[5:])
        if '@' in ss_url:
            part1, part2 = ss_url.split('@', 1)
            server_port = part2.split("/?")[0]
            server, port = server_port.split(":")
            clean_part1 = strip_non_base64(part1)
            decoded = decode_base64(clean_part1)
            method, password = decoded.decode().split(":", 1)
        else:
            clean_all = strip_non_base64(ss_url.split("/?")[0])
            decoded_all = decode_base64(clean_all)
            method, rest = decoded_all.decode().split(":", 1)
            password, server_port = rest.rsplit("@", 1)
            server, port = server_port.split(":", 1)
        return {
            "name": ensure_unique_name(name),
            "type": "ss",
            "server": server,
            "port": int(port),
            "cipher": method,
            "password": password,
            "udp": True
        }

    def parse_vmess(raw_link, name):
        try:
            clean_link = raw_link.split('（')[0].split('(')[0].strip()
            vmess_b64 = clean_link[8:]
            vmess_b64_clean = re.sub(r'[^A-Za-z0-9+/=]', '', vmess_b64)
            vmess_json = decode_base64(vmess_b64_clean)
            vmess_data = json.loads(vmess_json.decode())
            return {
                "name": ensure_unique_name(name),
                "type": "vmess",
                "server": vmess_data.get("add"),
                "port": int(vmess_data.get("port")),
                "uuid": vmess_data.get("id"),
                "alterId": int(vmess_data.get("aid", 0)),
                "cipher": "auto",
                "tls": vmess_data.get("tls", "") == "tls",
                "network": vmess_data.get("net", "tcp"),
                "udp": True
            }
        except Exception as e:
            log_file.write(f"❌ vmess 解析错误: {raw_link} | {e}\n")
            raise

    def parse_vless(raw_link, name):
        clean_link = raw_link.split('（')[0].split('(')[0].strip()
        parsed = urlparse(clean_link)
        uuid = parsed.username
        server = parsed.hostname
        port = parsed.port
        params = parse_qs(parsed.query)
        encryption = params.get("encryption", ["none"])[0]
        flow = params.get("flow", [None])[0]
        tls = params.get("security", [""])[0] == "tls"
        network = params.get("type", ["tcp"])[0]
        return {
            "name": ensure_unique_name(name),
            "type": "vless",
            "server": server,
            "port": port,
            "uuid": uuid,
            "encryption": encryption,
            "flow": flow,
            "tls": tls,
            "network": network,
            "udp": True
        }

    def parse_trojan(raw_link, name):
        clean_link = raw_link.split('（')[0].split('(')[0].strip()
        parsed = urlparse(clean_link)
        password = parsed.username
        server = parsed.hostname
        port = parsed.port
        return {
            "name": ensure_unique_name(name),
            "type": "trojan",
            "server": server,
            "port": port,
            "password": password,
            "tls": True,
            "udp": True
        }

    SUPPORTED_CIPHERS_SS = {
        "aes-128-gcm", "aes-192-gcm", "aes-256-gcm",
        "chacha20-ietf-poly1305", "xchacha20-ietf-poly1305",
        "aes-128-cfb", "aes-192-cfb", "aes-256-cfb"
    }
    SUPPORTED_NETWORKS = {"tcp", "ws", "grpc", "h2", "http"}

    def validate_node(node):
        for field in ["name", "server", "port"]:
            if field not in node or not node[field]:
                return False, f"缺少字段: {field}"
        try:
            socket.gethostbyname(node["server"])
        except:
            return False, f"域名不可解析: {node['server']}"
        try:
            port = int(node["port"])
            if not (0 < port < 65536):
                return False, f"端口范围错误: {port}"
        except:
            return False, f"端口格式错误: {node['port']}"
        if node["type"] == "ss":
            if node.get("cipher") not in SUPPORTED_CIPHERS_SS:
                return False, f"不支持的加密方式: {node.get('cipher')}"
        elif node["type"] in ["vmess", "vless"]:
            uuid = node.get("uuid")
            if not uuid or len(uuid) != 36 or uuid.count('-') != 4:
                return False, f"UUID 格式错误: {uuid}"
            if node.get("network") not in SUPPORTED_NETWORKS:
                return False, f"不支持的 network: {node.get('network')}"
            if node["type"] == "vless" and node.get("encryption", "none") != "none":
                return False, "vless 加密必须为 none"
        elif node["type"] == "trojan":
            if not node.get("password"):
                return False, "Trojan 密码不能为空"
            if not node.get("tls"):
                return False, "Trojan 必须启用 TLS"
        return True, "验证通过"

    # === 支持“下一行括号备注自动合并” ===
    with open(nodes_file, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip() and not line.startswith("#")]
        links = []
        skip_next = False
        for idx, line in enumerate(lines):
            if skip_next:
                skip_next = False
                continue
            if idx + 1 < len(lines) and re.match(r'^[（(].*?[）)]$', lines[idx + 1]):
                combined = line + lines[idx + 1]
                links.append(combined)
                skip_next = True
            else:
                links.append(line)

    used_names = {}
    new_proxies = []

    for idx, link in enumerate(links):
        try:
            if "#" in link:
                raw_link, raw_name = link.split("#", 1)
                raw_name = unquote(raw_name).strip()
                bracket_match = re.search(r'（(.*?)）', raw_name) or re.search(r'\((.*?)\)', raw_name)
                if bracket_match:
                    name = bracket_match.group(1).strip()
                else:
                    name = raw_name if raw_name else f"网络{idx+1}"
            else:
                raw_link = link.strip()
                bracket_match = re.search(r'（(.*?)）$', raw_link) or re.search(r'\((.*?)\)$', raw_link)
                if bracket_match:
                    name = bracket_match.group(1).strip()
                else:
                    name = f"网络{idx+1}"
            name = clean_name(name)

            if raw_link.startswith("ss://"):
                node = parse_ss(raw_link, name)
            elif raw_link.startswith("vmess://"):
                node = parse_vmess(raw_link, name)
            elif raw_link.startswith("vless://"):
                node = parse_vless(raw_link, name)
            elif raw_link.startswith("trojan://"):
                node = parse_trojan(raw_link, name)
            else:
                msg = f"⚠️ 不支持的协议: {link}"
                print(msg)
                log_file.write(msg + "\n")
                continue

            is_valid, msg = validate_node(node)
            if not is_valid:
                msg_full = f"❌ 节点验证失败: {name} [{node['type']}] {node['server']}:{node['port']} -> {msg}"
                print(msg_full)
                log_file.write(msg_full + "\n")
                continue

            new_proxies.append(node)
            success_msg = f"✅ 已解析: {node['name']}"
            print(success_msg)
            log_file.write(success_msg + "\n")

        except Exception as e:
            error_msg = f"❌ 解析错误: {link} | {e}"
            print(error_msg)
            log_file.write(error_msg + "\n")

    # === 新增精准比较：若节点无实质变化则不写入文件、不重启 ===
    new_proxy_sorted = sorted(
        [json.dumps(p, sort_keys=True, ensure_ascii=False) for p in new_proxies]
    )
    existing_proxy_sorted = sorted(
        [json.dumps(p, sort_keys=True, ensure_ascii=False) for p in (config.get("proxies") or [])]
    )

    if new_proxy_sorted == existing_proxy_sorted:
        final_total = len(existing_proxy_sorted)
        msg = f"✅ 节点未发生实质变化，无需重启 OpenClash，总节点：{final_total} 个"
        print(msg)
        log_file.write(msg + "\n")
        log_file.close()
        if os.path.exists(lock_file):
            os.remove(lock_file)
        exit(0)

    # === 写入配置并重启 ===
    test_file = "/tmp/clash_verify_test.yaml"
    config["proxies"] = new_proxies
    proxy_names = [p["name"] for p in new_proxies]

    for i in range(2, 255):
        group_name = f"手机{str(i).zfill(3)}"
        for group in config.get("proxy-groups", []):
            if group.get("name") == group_name:
                group["proxies"] = ["REJECT", "DIRECT"] + proxy_names

    with open(test_file, "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, allow_unicode=True, sort_keys=False)

    print("🔍 正在验证配置可用性 ...")
    verify_result = os.system(f"/etc/init.d/openclash verify_config {test_file} > /dev/null 2>&1")
    if verify_result != 0:
        print("❌ 配置验证失败，未写入配置，已退出")
        log_file.write("❌ 配置验证失败，未写入配置，已退出\n")
        log_file.close()
        os.remove(test_file)
        exit(1)
    os.remove(test_file)

    backup_file = f"{config_file}.bak"
    os.system(f"cp {config_file} {backup_file}")
    with open(config_file, "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, allow_unicode=True, sort_keys=False)
    print("✅ 配置验证通过，已写入配置并备份")

    print("✅ 配置写入完成，正在重启 OpenClash ...")
    os.system("/etc/init.d/openclash restart")
    time.sleep(8)

    check_log = os.popen("logread | grep 'Parse config error' | tail -n 5").read()
    if "Parse config error" in check_log:
        print("❌ 检测到配置解析错误，正在回滚 ...")
        log_file.write("❌ 检测到配置解析错误，已触发回滚\n")
        os.system(f"cp {backup_file} {config_file}")
        os.system("/etc/init.d/openclash restart")
        log_file.close()
        exit(1)

    final_total = len(new_proxies)
    msg = f"✅ 本次执行完成，已写入新配置并重启，总节点：{final_total} 个"
    print(msg)
    log_file.write(msg + "\n")

    print("✅ OpenClash 已重启运行，节点已同步完成")
    log_file.write("✅ OpenClash 已重启运行，节点已同步完成\n")
    log_file.close()

except Exception as e:
    print(f"❌ 脚本执行出错: {e}")
    try:
        log_file.write(f"❌ 脚本执行出错: {e}\n")
        log_file.close()
    except:
        pass

finally:
    if os.path.exists(lock_file):
        os.remove(lock_file)

# zw.py
from ruamel.yaml import YAML
import copy
import os
from jx import parse_nodes
from log import write_log

yaml = YAML()
yaml.preserve_quotes = True

def get_openclash_config_path() -> str:
    try:
        return os.popen("uci get openclash.config.config_path").read().strip()
    except Exception:
        return ""

def load_config(path: str):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.load(f)
    except:
        return {}

def inject_proxies(config, nodes: list) -> tuple:
    if "proxies" not in config or not isinstance(config["proxies"], list):
        config["proxies"] = []

    existing_names = {proxy.get("name") for proxy in config["proxies"]}
    new_nodes = []
    injected = 0

    for node in nodes:
        if node["name"] not in existing_names:
            new_nodes.append(node)
            injected += 1
        else:
            write_log(f"⚠️ [zw] 跳过重复节点: {node['name']}")

    config["proxies"].extend(new_nodes)
    return config, injected

def main():
    write_log("📦 [zw] 开始注入 proxies 网络节点...")

    config_path = get_openclash_config_path()
    if not config_path:
        write_log("❌ [zw] 获取配置路径失败，终止执行。")
        return

    config_data = load_config(config_path)
    if not config_data:
        write_log("❌ [zw] 配置文件读取失败，终止执行。")
        return

    nodes = parse_nodes("/root/OpenClashManage/wangluo/nodes.txt")
    if not nodes:
        write_log("⚠️ [zw] 未获取到有效节点，跳过注入。")
        return

    updated_config, count = inject_proxies(config_data, nodes)
    if count == 0:
        write_log("🔁 [zw] 无新节点注入。")
        return

    try:
        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(updated_config, f)
        write_log(f"✅ [zw] 成功注入 {count} 条新节点。")
    except Exception as e:
        write_log(f"❌ [zw] 写入配置失败: {e}")

if __name__ == "__main__":
    main()

import os
import re
import json
import base64
from urllib.parse import unquote
from typing import List, Dict

LOG_DIR = "/root/OpenClashManage/wangluo"
os.makedirs(LOG_DIR, exist_ok=True)

def log_error(msg: str):
    with open(f"{LOG_DIR}/parse_errors.log", "a", encoding="utf-8") as f:
        f.write(msg + "\n")

def log_success(msg: str):
    with open(f"{LOG_DIR}/parse_success.log", "a", encoding="utf-8") as f:
        f.write(msg + "\n")

def decode_base64(data: str) -> str:
    data += '=' * (-len(data) % 4)
    return base64.urlsafe_b64decode(data).decode()

def clean_name(name: str, existing_names: set) -> str:
    name = re.sub(r'[^\w\-]', '', name.strip())[:24]
    original = name
    count = 1
    while name in existing_names:
        name = f"{original}_{count}"
        count += 1
    existing_names.add(name)
    return name

def extract_custom_name(link: str) -> str:
    match = re.search(r'#(.+)', link)
    if match:
        name = unquote(match.group(1))
        bracket_match = re.search(r'[(（](.*?)[)）]', name)
        return bracket_match.group(1) if bracket_match else name
    return "Unnamed"

def parse_nodes(file_path: str, log_file=None) -> List[Dict]:
    parsed_nodes = []
    existing_names = set()
    success_count = 0
    error_count = 0

    with open(file_path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip() and not line.startswith("#")]

    for line in lines:
        try:
            if line.startswith("ss://"):
                raw = line[5:]
                parts = raw.split("@")
                if len(parts) == 2:
                    info, server = parts
                    info = decode_base64(info)
                    method, password = info.split(":", 1)
                    host, port = server.split(":")[0], server.split(":")[1].split("#")[0]
                else:
                    decoded = decode_base64(raw.split("#")[0].split("?")[0])
                    method_password, server = decoded.split("@")
                    method, password = method_password.split(":")
                    host, port = server.split(":")
                name = clean_name(extract_custom_name(line), existing_names)
                parsed_nodes.append({
                    "name": name,
                    "type": "ss",
                    "server": host,
                    "port": int(port),
                    "cipher": method,
                    "password": password,
                })
                success_count += 1

            elif line.startswith("vmess://"):
                decoded = decode_base64(line[8:].split("#")[0])
                node = eval(decoded) if "{" in decoded else json.loads(decoded)
                name = clean_name(extract_custom_name(line), existing_names)
                parsed_nodes.append({
                    "name": name,
                    "type": "vmess",
                    "server": node["add"],
                    "port": int(node["port"]),
                    "uuid": node["id"],
                    "alterId": int(node.get("aid", 0)),
                    "cipher": node.get("type", "auto"),
                    "tls": node.get("tls", "").lower() == "tls"
                })
                success_count += 1

            elif line.startswith("vless://"):
                info = line[8:].split("#")[0]
                name = clean_name(extract_custom_name(line), existing_names)
                parts = info.split("@")
                uuid = parts[0]
                server_port = parts[1].split("?")[0]
                host, port = server_port.split(":")
                parsed_nodes.append({
                    "name": name,
                    "type": "vless",
                    "server": host,
                    "port": int(port),
                    "uuid": uuid,
                    "encryption": "none",
                    "tls": "tls" in info
                })
                success_count += 1

            elif line.startswith("trojan://"):
                body = line[9:].split("#")[0]
                password, hostport = body.split("@")
                host, port = hostport.split(":")
                name = clean_name(extract_custom_name(line), existing_names)
                parsed_nodes.append({
                    "name": name,
                    "type": "trojan",
                    "server": host,
                    "port": int(port),
                    "password": password
                })
                success_count += 1

            else:
                msg = f"[WARN] 不支持的协议: {line[:30]}"
                log_error(msg)
                error_count += 1

        except Exception as e:
            log_error(f"[ERROR] 解析失败: {line[:60]} -> {e}")
            error_count += 1

    log_success(f"[INFO] 共解析成功 {success_count} 条，失败 {error_count} 条。")
    return parsed_nodes

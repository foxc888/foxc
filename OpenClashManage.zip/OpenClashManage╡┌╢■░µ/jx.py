import os
import re
import json
import base64
from urllib.parse import unquote, urlparse, parse_qs
from typing import List, Dict
from log import write_log  # ✅ 使用统一日志输出

def decode_base64(data: str) -> str:
    try:
        data = unquote(data.strip())
        if '\n' in data or '\\n' in data:
            write_log("⚠️ [decode] 检测到换行符，可能为 JSON 格式错误", module="jx")
        data = data.replace('\n', '').replace('\r', '').replace(' ', '')
        data = re.sub(r'[^A-Za-z0-9+/=]', '', data)
        remain = len(data) % 4
        if remain == 1:
            write_log("⚠️ [decode] base64长度非法，截断尾部1字符", module="jx")
            data = data[:-1]
        elif remain in (2, 3):
            data += '=' * (4 - remain)
        decoded_bytes = base64.b64decode(data)
        return decoded_bytes.decode("utf-8", errors="ignore")
    except Exception as e:
        write_log(f"❌ [decode] Base64解码失败 → {e}", module="jx")
        return "{}"

def clean_name(name: str, existing_names: set) -> str:
    name = name.strip() or "Unnamed"
    base = name[:40]  # 截断以防过长
    new_name = base
    count = 1
    while new_name in existing_names:
        new_name = f"{base}_{count}"
        count += 1
    existing_names.add(new_name)
    return new_name

def extract_custom_name(link: str, fallback: str = "Unnamed") -> str:
    """
    优先使用链接中 # 或括号中的自定义名称，其次使用 fallback（如 ps 字段）
    """
    match = re.search(r'#(.+)', link)
    if match:
        name = unquote(match.group(1))
        bracket_match = re.search(r'[（(](.*?)[)）]', name)
        return bracket_match.group(1) if bracket_match else name
    return fallback

def parse_plugin_params(query: str) -> Dict:
    params = parse_qs(query)
    plugin_opts = {}
    if 'plugin' in params:
        plugin_str = params['plugin'][0]
        plugin_opts['plugin'] = plugin_str
        if 'obfs=http' in plugin_str:
            plugin_opts['obfs'] = 'http'
        elif 'obfs=tls' in plugin_str:
            plugin_opts['obfs'] = 'tls'
        host_match = re.search(r'obfs-host=([^;]+)', plugin_str)
        if host_match:
            plugin_opts['obfs-host'] = host_match.group(1)
        mode_match = re.search(r'mode=([^;]+)', plugin_str)
        if mode_match:
            plugin_opts['mode'] = mode_match.group(1)
        if 'udp-over-tcp=true' in plugin_str.lower():
            plugin_opts['udp-over-tcp'] = True
    return plugin_opts

def extract_host_port(hostport: str) -> (str, int):
    hostport = hostport.strip().split('/')[0].split('?')[0].split('#')[0]
    match = re.match(r"^(.*):(\d+)$", hostport)
    if not match:
        raise ValueError(f"无效 host:port 格式: {hostport}")
    return match.group(1), int(match.group(2))

def safe_alpn(value) -> list:
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        return [v.strip() for v in value.split(',') if v.strip()]
    return []

def parse_multi_host(host_str: str) -> str:
    if ',' in host_str:
        hosts = [h.strip() for h in host_str.split(',') if h.strip()]
        return hosts[0]
    return host_str.strip()

def parse_nodes(file_path: str) -> List[Dict]:
    parsed_nodes = []
    existing_names = set()
    success_count = 0
    error_count = 0

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip() and not line.startswith("#")]
    except Exception as e:
        write_log(f"❌ [parse] 无法读取节点文件: {e}", module="jx")
        return []

    for line in lines:
        try:
            if line.startswith("ss://"):
                raw = line[5:]
                name = clean_name(extract_custom_name(line), existing_names)
                if '@' in raw:
                    info, server = raw.split("@", 1)
                    info = decode_base64(info)
                    if not info:
                        raise ValueError("Base64解码失败")
                    method, password = info.split(":", 1)
                    hostport = server.split("#")[0].split("?")[0]
                    host, port = extract_host_port(hostport)
                    query = urlparse(line).query
                    plugin_opts = parse_plugin_params(query)
                    node = {
                        "name": name,
                        "type": "ss",
                        "server": host,
                        "port": port,
                        "cipher": method,
                        "password": password
                    }
                    if plugin_opts:
                        node.update(plugin_opts)
                    parsed_nodes.append(node)
                else:
                    decoded = decode_base64(raw.split("#")[0].split("?")[0])
                    if not decoded:
                        raise ValueError("Base64解码失败")
                    method_password, server = decoded.split("@")
                    method, password = method_password.split(":")
                    host, port = extract_host_port(server)
                    parsed_nodes.append({
                        "name": name,
                        "type": "ss",
                        "server": host,
                        "port": port,
                        "cipher": method,
                        "password": password
                    })
                success_count += 1

            elif line.startswith("vmess://"):
                raw = line[8:].split("#")[0]
                decoded = decode_base64(raw)
                if not decoded:
                    raise ValueError("Base64解码失败")
                node = json.loads(decoded)
                name = clean_name(extract_custom_name(line, fallback=node.get("ps", "Unnamed")), existing_names)
                server = parse_multi_host(node.get("add", ""))
                port = int(str(node.get("port", "0")).strip())
                uuid = node.get("id", "").strip()
                alterId = int(str(node.get("aid", "0")).strip() or 0)
                cipher = node.get("type", "auto")
                tls = node.get("tls", "").lower() == "tls"
                network = node.get("net", "tcp").lower()
                path = node.get("path", "") or ""
                host = parse_multi_host(node.get("host", "") or "")
                vmess_node = {
                    "name": name,
                    "type": "vmess",
                    "server": server,
                    "port": port,
                    "uuid": uuid,
                    "alterId": alterId,
                    "cipher": cipher,
                    "tls": tls,
                    "network": network,
                    "sni": node.get("sni", ""),
                    "alpn": safe_alpn(node.get("alpn", [])),
                    "fp": node.get("fp", ""),
                    "scy": node.get("scy", "auto"),
                    "skip-cert-verify": node.get("allowInsecure", "false").lower() == "true"
                }
                if network == "ws":
                    vmess_node["ws-opts"] = {
                        "path": path,
                        "headers": {"Host": host}
                    }
                if not all([server, port, uuid]):
                    raise ValueError(f"字段缺失 → server={server}, port={port}, uuid={uuid}")
                parsed_nodes.append(vmess_node)
                success_count += 1

            elif line.startswith("vless://"):
                info = line[8:].split("#")[0]
                name = clean_name(extract_custom_name(line), existing_names)
                parts = info.split("@")
                if len(parts) != 2:
                    raise ValueError("字段格式不正确")
                uuid = parts[0]
                parsed = urlparse("//" + parts[1])
                host, port = parsed.hostname, parsed.port
                query = parse_qs(parsed.query)
                if not all([host, port, uuid]):
                    raise ValueError(f"字段缺失 → host={host}, port={port}, uuid={uuid}")
                parsed_nodes.append({
                    "name": name,
                    "type": "vless",
                    "server": host,
                    "port": int(port),
                    "uuid": uuid,
                    "encryption": query.get("encryption", ["none"])[0],
                    "flow": query.get("flow", [None])[0],
                    "tls": query.get("security", ["none"])[0] == "tls",
                    "sni": query.get("sni", [""])[0],
                    "alpn": safe_alpn(query.get("alpn", [])),
                    "fp": query.get("fp", [""])[0],
                    "skip-cert-verify": query.get("allowInsecure", ["false"])[0].lower() == "true",
                    "ws-opts": {
                        "path": query.get("path", [""])[0],
                        "headers": {"Host": query.get("host", [""])[0]}
                    } if query.get("type", [""])[0] == "ws" else None
                })
                success_count += 1

            elif line.startswith("trojan://"):
                body = line[9:].split("#")[0]
                parsed = urlparse("//" + body)
                password = parsed.username
                host, port = parsed.hostname, parsed.port
                query = parse_qs(parsed.query)
                name = clean_name(extract_custom_name(line), existing_names)
                if not all([host, port, password]):
                    raise ValueError(f"字段缺失 → host={host}, port={port}, password={password}")
                trojan_node = {
                    "name": name,
                    "type": "trojan",
                    "server": host,
                    "port": int(port),
                    "password": password,
                    "sni": query.get("sni", [""])[0],
                    "alpn": safe_alpn(query.get("alpn", [])),
                    "fp": query.get("fp", [""])[0],
                    "skip-cert-verify": query.get("allowInsecure", ["false"])[0].lower() == "true",
                    "network": query.get("type", ["tcp"])[0]
                }
                if trojan_node["network"] == "ws":
                    trojan_node["ws-opts"] = {
                        "path": query.get("path", [""])[0],
                        "headers": {"Host": query.get("host", [""])[0]}
                    }
                parsed_nodes.append(trojan_node)
                success_count += 1

            else:
                write_log(f"⚠️ [parse] 不支持的协议: {line[:30]}", module="jx")
                error_count += 1

        except Exception as e:
            write_log(f"❌ [parse] 解析失败 ({line[:30]}) → {e}", module="jx")
            error_count += 1

    write_log(f"✅ [parse] 成功解析 {success_count} 条，失败 {error_count} 条", module="jx")
    write_log("------------------------------------------------------------", module="jx")
    return parsed_nodes
